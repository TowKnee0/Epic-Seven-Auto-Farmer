import cv2
from PIL import ImageGrab
import numpy
import random
import pyautogui
import tkinter as tk

start = cv2.imread('Images\E7\Start.PNG', 1)
repeat_end = cv2.imread('Images\E7\RepeatEnd.PNG', 1)
confirm = cv2.imread('Images\E7\Confirm.PNG', 1)
try_again = cv2.imread('Images\E7\TryAgain.PNG', 1)
hunt_items = cv2.imread('Images\E7\Items.PNG', 1)
game_guide = cv2.imread('Images\E7\Guide.PNG', 1)
buy = cv2.imread('Images\E7\Buy.PNG', 1)
energy = cv2.imread('Images\E7\Energy.PNG', 1)

endSW = cv2.imread('Images\SW\EndSW.PNG', 1)
ok = cv2.imread('Images\SW\OK.PNG', 1)
replay = cv2.imread('Images\SW\Replay.PNG', 1)

class Operations:
    @staticmethod
    def check_match(screen, template, threshold):
        chan, w, h = template.shape[::-1]
        filtered_point = numpy.where(cv2.matchTemplate(screen, template, cv2.TM_CCOEFF_NORMED) >= threshold)
        for point in zip(*filtered_point[::-1]):
            rect = (point[0], point[1], w, h)
            return rect
        return False
    @staticmethod
    def random_mouse(rect):
        pyautogui.moveTo(rect[0] + random.randrange(rect[2]) ,rect[1] + random.randrange(rect[3]))
        pyautogui.click()
    @staticmethod
    def grab_screen():
        screen = cv2.cvtColor(numpy.array(ImageGrab.grab()), cv2.COLOR_BGR2RGB)
        return screen

class Content:
    def __init__(self, content):
        self.content = content

    def Repeat(self):

        if self.content == "EPIC SEVEN":
            current_screen = Operations.grab_screen()
            repeat_stopped = Operations.check_match(current_screen, repeat_end, 0.9)
            confirm_visible = Operations.check_match(current_screen, confirm, 0.9)
            try_again_visible = Operations.check_match(current_screen, try_again, 0.9)
            start_battle = Operations.check_match(current_screen, start, 0.9)
            battle_end = Operations.check_match(current_screen, hunt_items, 0.9)
            fail = Operations.check_match(current_screen, game_guide, 0.9)
            energy_vis = Operations.check_match(current_screen, energy, 0.9)
            buy_btn = Operations.check_match(current_screen, buy, 0.9)

            if repeat_stopped and confirm_visible != False:
                Operations.random_mouse(confirm_visible)
                cv2.waitKey(2000)

            if try_again_visible and repeat_stopped != False:
                Operations.random_mouse(try_again_visible)
                cv2.waitKey(2000)

            if start_battle != False:
                Operations.random_mouse(start_battle)

            if energy_vis != False:
                Operations.random_mouse(buy_btn)

        elif self.content == "SUMMONERS WAR":

            current_screen = Operations.grab_screen()
            end_vis = Operations.check_match(current_screen, endSW, 0.9)

            if end_vis != False:
                Operations.random_mouse((end_vis[0] - 300, end_vis[1], end_vis[2] + 300, end_vis[3] + 200))
                cv2.waitKey(5000)

                Operations.random_mouse((end_vis[0] - 300, end_vis[1], end_vis[2] + 300, end_vis[3] + 200))
                cv2.waitKey(5000)

                try:
                    Operations.random_mouse(Operations.check_match(Operations.grab_screen(), ok, 0.9))
                    cv2.waitKey(3000)

                    Operations.random_mouse(Operations.check_match(Operations.grab_screen(), replay, 0.9))
                except:
                    pass

farm = Content('EPIC SEVEN')

inPlay = True
while inPlay:

    farm.Repeat()

    cv2.waitKey(5000)
