my_set = {'Hello', 'World'}

print({word[0] for word in my_set})